/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author harshbidhuri
 */
import java.sql.*;
import javax.swing.JOptionPane;
public class javaconnect {
    Connection conn;
    
    public static Connection ConnectDb(){
    try{
        Class.forName("com.mysql.jdbc.Driver");
        String UID="root";
        String PWD="0000";
        String DB_URL= "jdbc:mysql://localhost/lms?zeroDateTimeBehavior=convertToNull";
        Connection conn= DriverManager.getConnection(DB_URL,UID,PWD);
        return conn;
    }
    catch(Exception e){
        JOptionPane.showMessageDialog(null,"javaconnect          "+e);
        return null;
    }
    }
}
